import os
import tensorflow as tf
import random
import copy
import numpy as np
from scipy import interpolate
from sklearn import preprocessing
from scipy.io import loadmat
from scipy.signal import savgol_filter
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline      # for warping
#  from transforms3d.axangles import axangle2mat  # for rotation
#%%
def pre_process(f, length = 300):
    scale = np.linspace(1, len(f), len(f)) #resample
    new_scale = np.linspace(1, len(f), length)
    func_F = interpolate.interp1d(scale, f, kind='linear')
    F_new = func_F(new_scale)
    #data = preprocessing.scale(F_new) #z-score
    return F_new

def resize(data, kind = 'linear', length = 300):
    scale = np.linspace(1, np.shape(data)[0], np.shape(data)[0])#resample
    new_scale = np.linspace(1, np.shape(data)[0], length)
    
    func_F = interpolate.interp1d(scale, data[:,0], kind=kind)
    F_new = func_F(new_scale)
    
    func_P = interpolate.interp1d(scale, data[:,1], kind=kind)
    P_new = func_P(new_scale)
  
    waveData = np.array([F_new, P_new]).T
    
    #r = [preprocessing.scale(waveData)][0]#z-score
    return waveData
#%%

#%% 1.Jitter

def Jittering(X, sigma = 0.3):
    noise = np.random.normal(loc=0, scale=sigma, size=X.shape)
    r = X + noise
    return r#, noise


#%% 2.Scaling 

def Scaling(X, sigma = 0.2):
    scalingFactor = np.random.normal(loc=1, scale=sigma, size=(1,X.shape[1]))
    noise = np.matmul(np.ones((X.shape[0],1)), scalingFactor)
    r = X * noise
    return r#, noise


#%% 3. Magnitude Warping

# #### Hyperparameters :  sigma = STD of the random knots for generating curves
# #### knot = # of knots for the random curves (complexity of the curves)
# "Scaling" can be considered as "applying constant noise to the entire samples" whereas "Jittering" can be considered as "applying different noise to each sample". 
# "Magnitude Warping" can be considered as "applying smoothly-varing noise to the entire samples"


## This example using cubic splice is not the best approach to generate random curves. 
## You can use other aprroaches, e.g., Gaussian process regression, Bezier curve, etc.

def GenerateRandomCurves(X, sigma=0.2, knot=4):
    xx = (np.ones((X.shape[1],1))*(np.arange(0,X.shape[0], (X.shape[0]-1)/(knot+1)))).transpose()
    yy = np.random.normal(loc=1.0, scale=sigma, size=(knot+2, X.shape[1]))
    x_range = np.arange(X.shape[0])
    cs_x = CubicSpline(xx[:,0], yy[:,0])
    cs_y = CubicSpline(xx[:,1], yy[:,1])
    return np.array([cs_x(x_range),cs_y(x_range)]).transpose()

def MagnitudeWarping(X, sigma=0.2, knot=4):
    cs = GenerateRandomCurves(X, sigma=0.2, knot=4)
    r = X * cs
    return r#, cs





#%% 4. Time Warping

# #### Hyperparameters :  sigma = STD of the random knots for generating curves
# #### knot = # of knots for the random curves (complexity of the curves)

def DistortTimesteps(X, sigma=0.2, knot=4):
    tt = GenerateRandomCurves(X, sigma, knot) # Regard these samples aroun 1 as time intervals
    tt_cum = np.cumsum(tt, axis=0)        # Add intervals to make a cumulative graph
    # Make the last value to have X.shape[0]
    t_scale = [(X.shape[0]-1)/tt_cum[-1,0], (X.shape[0]-1)/tt_cum[-1,1] ]
    tt_cum[:,0] = tt_cum[:,0]*t_scale[0]
    tt_cum[:,1] = tt_cum[:,1]*t_scale[1]
    return tt_cum

def TimeWarping(X, sigma=0.2, knot=4):
    tt_new = DistortTimesteps(X, sigma, knot)

    X_new = np.zeros(X.shape)
    x_range = np.arange(X.shape[0])
    X_new[:,0] = np.interp(x_range, tt_new[:,0], X[:,0])
    X_new[:,1] = np.interp(x_range, tt_new[:,1], X[:,1])
    return X_new#, tt_new



#%% 5. Rotation == Permutation
# #### Hyperparameters :  N/A

# axis = np.random.uniform(low=-1, high=1, size=X.shape[1])
# angle = np.random.uniform(low=-np.pi, high=np.pi)

# def DA_Rotation(X):
#     axis = np.random.uniform(low=-1, high=1, size=X.shape[1])
#     angle = np.random.uniform(low=-np.pi, high=np.pi)
#     return np.matmul(X , axangle2mat(axis,angle))

# r5 = DA_Rotation(X)

# fig = plt.figure()
# plt.plot(r5)
# plt.title("5")




#%% 6. Permutation
# #### Hyperparameters :  nPerm = # of segments to permute
# #### minSegLength = allowable minimum length for each segment

def Permutation1(X, nPerm=4, minSegLength=10):
    X_new = np.zeros(X.shape)
    idx = np.random.permutation(nPerm)
    bWhile = True
    while bWhile == True:
        segs = np.zeros(nPerm+1, dtype=int)
        segs[1:-1] = np.sort(np.random.randint(minSegLength, X.shape[0]-minSegLength, nPerm-1))
        segs[-1] = X.shape[0]
        if np.min(segs[1:]-segs[0:-1]) > minSegLength:
            bWhile = False
    pp = 0
    for ii in range(nPerm):
        x_temp = X[segs[idx[ii]]:segs[idx[ii]+1],:]
        X_new[pp:pp+len(x_temp),:] = x_temp
        pp += len(x_temp)
    return X_new



def Permutation2(X, nPerm=4, max_segments=8, seg_mode="random"):
    orig_steps = np.arange(X.shape[0])
    num_segs = np.random.randint(1, max_segments)
    ret = np.zeros_like(X)
    if num_segs > 1:
        if seg_mode == "random":
            split_points = np.random.choice(X.shape[0] - 2, num_segs - 1, replace=False)
            split_points.sort()
            splits = np.split(orig_steps, split_points)
        else:
            splits = np.array_split(orig_steps, num_segs)
        warp = np.concatenate(np.random.permutation(splits)).ravel()
    
        ret = X[warp]
    
    else:
        ret = X
    return ret



#%% 7. Random Sampling
# #### Hyperparameters :  nSample = # of subsamples (nSample <= X.shape[0])
# This approach is similar to TimeWarp, but will use only subsamples (not all samples) for interpolation. (Using TimeWarp is more recommended)
def RandSampleTimesteps(X, nSample=300):

    tt = np.zeros((nSample,X.shape[1]), dtype=int)
    tt[1:-1,0] = np.sort(np.random.randint(1,X.shape[0]-1,nSample-2))
    tt[1:-1,1] = np.sort(np.random.randint(1,X.shape[0]-1,nSample-2))
    tt[-1,:] = X.shape[0]-1
    return tt

def RandSampling(X, nSample=300):
    tt = RandSampleTimesteps(X, nSample)
    X_new = np.zeros(X.shape)
    X_new[:,0] = np.interp(np.arange(X.shape[0]), tt[:,0], X[tt[:,0],0])
    X_new[:,1] = np.interp(np.arange(X.shape[0]), tt[:,1], X[tt[:,1],1])
    return X_new

# r7 = RandSampling(X, nSample=300)

# dpi = 100
# fig = plt.figure(figsize=(6,4), dpi=dpi)
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] =False
# ts = 10
# ls = 13
# ax1 = fig.add_subplot(111)
# color1 = 'darkorange'
# color2 = 'bisque'
# p1, = ax1.plot(X[:,1], color=color2, alpha=alpha, label='Original Pressure')
# p2, = ax1.plot(r7[:,1], color=color1, label='RandSampling Pressure')
# ax1.set_ylabel('Pressue (cmH$_\mathrm{2}$O)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax1.tick_params(axis='y', labelcolor=color1, labelsize=ts)
# ax1.set_title("RandSampling",fontdict={'weight': 'normal', 'size': ls})

# ax2 = ax1.twinx() 
# color1 = 'lightseagreen'
# color2 = 'paleturquoise'
# p3, = ax2.plot(X[:,0], color=color2, alpha=alpha, label='Original Flow')
# p4, = ax2.plot(r7[:,0], color=color1, label='RandSampling Flow')
# ax2.set_ylabel('Flow (L/min)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax2.tick_params(axis='y', labelcolor=color1, labelsize=ts)

# ax1.legend(handles=[p1, p2, p3, p4], loc="upper right", fontsize=ts)
# plt.savefig('./augmentation results/7-RandSampling.png', dpi=dpi)
# plt.show()


#%% 8. reverse

def Reverse(s):
    fwaveData = s[:, 0]
    pwaveData = s[:, 1]
    
    r1 = list(reversed(fwaveData))
    r2 = list(reversed(pwaveData))
    
    r = np.array([r1, r2]).T
    return r

# r8 = Reverse(X)

# dpi = 100
# fig = plt.figure(figsize=(6,4), dpi=dpi)
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] =False
# ts = 10
# ls = 13
# ax1 = fig.add_subplot(111)
# color1 = 'darkorange'
# color2 = 'bisque'
# p1, = ax1.plot(X[:,1], color=color2, alpha=alpha, label='Original Pressure')
# p2, = ax1.plot(r8[:,1], color=color1, label='Reverse Pressure')
# ax1.set_ylabel('Pressue (cmH$_\mathrm{2}$O)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax1.tick_params(axis='y', labelcolor=color1, labelsize=ts)
# ax1.set_title("Reverse",fontdict={'weight': 'normal', 'size': ls})

# ax2 = ax1.twinx() 
# color1 = 'lightseagreen'
# color2 = 'paleturquoise'
# p3, = ax2.plot(X[:,0], color=color2, alpha=alpha, label='Original Flow')
# p4, = ax2.plot(r8[:,0], color=color1, label='Reverse Flow')
# ax2.set_ylabel('Flow (L/min)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax2.tick_params(axis='y', labelcolor=color1, labelsize=ts)

# ax1.legend(handles=[p1, p2, p3, p4], loc="upper right", fontsize=ts)
# plt.savefig('./augmentation results/8-Reverse.png', dpi=dpi)
# plt.show()

#%% 9.filp x
def FlipX(X):
    flip = [-1, -1]  
    r =  flip * X[:,:]
    return r

# r9 = FlipX(X)

# dpi = 100
# fig = plt.figure(figsize=(6,4), dpi=dpi)
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] =False
# ts = 10
# ls = 13
# ax1 = fig.add_subplot(111)
# color1 = 'darkorange'
# color2 = 'bisque'
# p1, = ax1.plot(X[:,1], color=color2, alpha=alpha, label='Original Pressure')
# p2, = ax1.plot(r9[:,1], color=color1, label='FlipX Pressure')
# ax1.set_ylabel('Pressue (cmH$_\mathrm{2}$O)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax1.tick_params(axis='y', labelcolor=color1, labelsize=ts)
# ax1.set_title("FlipX",fontdict={'weight': 'normal', 'size': ls})

# ax2 = ax1.twinx() 
# color1 = 'lightseagreen'
# color2 = 'paleturquoise'
# p3, = ax2.plot(X[:,0], color=color2, alpha=alpha, label='Original Flow')
# p4, = ax2.plot(r9[:,0], color=color1, label='FlipX Flow')
# ax2.set_ylabel('Flow (L/min)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax2.tick_params(axis='y', labelcolor=color1, labelsize=ts)

# ax1.legend(handles=[p1, p2, p3, p4], loc="upper right", fontsize=ts)
# plt.savefig('./augmentation results/9-FlipX.png', dpi=dpi)
# plt.show()

#%% 10.flip y 
# 和reverse效果一样
def FlipY(X):
    steps = list(np.arange(X.shape[0]-1, -1, -1))
    r = X[steps]
    return r

# r10 = FlipY(X)

# dpi = 100
# fig = plt.figure(figsize=(6,4), dpi=dpi)
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] =False
# ts = 10
# ls = 13
# ax1 = fig.add_subplot(111)
# color1 = 'darkorange'
# color2 = 'bisque'
# p1, = ax1.plot(X[:,1], color=color2, alpha=alpha, label='Original Pressure')
# p2, = ax1.plot(r10[:,1], color=color1, label='FlipY Pressure')
# ax1.set_ylabel('Pressue (cmH$_\mathrm{2}$O)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax1.tick_params(axis='y', labelcolor=color1, labelsize=ts)
# ax1.set_title("FlipY",fontdict={'weight': 'normal', 'size': ls})

# ax2 = ax1.twinx() 
# color1 = 'lightseagreen'
# color2 = 'paleturquoise'
# p3, = ax2.plot(X[:,0], color=color2, alpha=alpha, label='Original Flow')
# p4, = ax2.plot(r10[:,0], color=color1, label='FlipY Flow')
# ax2.set_ylabel('Flow (L/min)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax2.tick_params(axis='y', labelcolor=color1, labelsize=ts)

# ax1.legend(handles=[p1, p2, p3, p4], loc="upper right", fontsize=ts)
# plt.savefig('./augmentation results/10-FlipY.png', dpi=dpi)
# plt.show()


#%% 11.blockout
def Masked(X, minMaskLength = 5, maxMaskLength = 10, mask_mode="random"):
    blockout_point = np.random.randint(0, X.shape[0], size=(X.shape[1]))
    
    X_new = copy.deepcopy(X)
    for i in range(X.shape[1]):
        if mask_mode == "random":
            maskLength = np.random.randint(minMaskLength, maxMaskLength+1, 1)[0]
            if blockout_point[i]+maskLength<X_new.shape[0]:
                X_new[blockout_point[i]:blockout_point[i]+maskLength, i]=0

        else:
            if blockout_point[i]+minMaskLength<X_new.shape[0]:
                X_new[blockout_point[i]:blockout_point[i]+minMaskLength, i]=0

    return X_new

# r11 = Masked(X, minMaskLength = 5, maxMaskLength = 10, mask_mode="random")

# dpi = 100
# fig = plt.figure(figsize=(6,4), dpi=dpi)
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] =False
# ts = 10
# ls = 13
# ax1 = fig.add_subplot(111)
# color1 = 'darkorange'
# color2 = 'bisque'
# p1, = ax1.plot(X[:,1], color=color2, alpha=alpha, label='Original Pressure')
# p2, = ax1.plot(r11[:,1], color=color1, label='Masked Pressure')
# ax1.set_ylabel('Pressue (cmH$_\mathrm{2}$O)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax1.tick_params(axis='y', labelcolor=color1, labelsize=ts)
# ax1.set_title("Masked",fontdict={'weight': 'normal', 'size': ls})

# ax2 = ax1.twinx() 
# color1 = 'lightseagreen'
# color2 = 'paleturquoise'
# p3, = ax2.plot(X[:,0], color=color2, alpha=alpha, label='Original Flow')
# p4, = ax2.plot(r11[:,0], color=color1, label='Masked Flow')
# ax2.set_ylabel('Flow (L/min)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax2.tick_params(axis='y', labelcolor=color1, labelsize=ts)

# ax1.legend(handles=[p1, p2, p3, p4], loc="upper right", fontsize=ts)
# plt.savefig('./augmentation results/11-Masked.png', dpi=dpi)
# plt.show()
        
    


#%% 12.crop-and-resize
def Crop_and_Resize(X):
    if X.shape[0]>20:
        crop_point = np.random.randint(1, 15)
        h = np.random.choice([-1,1])
        if h == 1:
            X_new = X[crop_point:, :]
        else:
            X_new = X[:-crop_point, :]
        #print(X_new.shape)
        r = resize(X_new, kind='linear', length=X.shape[0])
    else:
        r = X
            
    return r

# r12 = Crop_and_Resize(X)

# dpi = 100
# fig = plt.figure(figsize=(6,4), dpi=dpi)
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] =False
# ts = 10
# ls = 13
# ax1 = fig.add_subplot(111)
# color1 = 'darkorange'
# color2 = 'bisque'
# p1, = ax1.plot(X[:,1], color=color2, alpha=alpha, label='Original Pressure')
# p2, = ax1.plot(r12[:,1], color=color1, label='Crop and Resize Pressure')
# ax1.set_ylabel('Pressue (cmH$_\mathrm{2}$O)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax1.tick_params(axis='y', labelcolor=color1, labelsize=ts)
# ax1.set_title("Crop and Resize",fontdict={'weight': 'normal', 'size': ls})

# ax2 = ax1.twinx() 
# color1 = 'lightseagreen'
# color2 = 'paleturquoise'
# p3, = ax2.plot(X[:,0], color=color2, alpha=alpha, label='Original Flow')
# p4, = ax2.plot(r12[:,0], color=color1, label='Crop and Resize Flow')
# ax2.set_ylabel('Flow (L/min)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax2.tick_params(axis='y', labelcolor=color1, labelsize=ts)

# ax1.legend(handles=[p1, p2, p3, p4], loc="upper right", fontsize=ts)
# plt.savefig('./augmentation results/12Crop_and_Resize.png', dpi=dpi)
# plt.show()


#%% 13.randoom smoothing

def np_move_avg(a, n, mode="same"):
  return(np.convolve(a, np.ones((n,))/n, mode=mode))


def RandoomSmoothing(X, minwindowsize=2, maxwindowsize=8, mode="same"):
    n = np.random.randint(minwindowsize, maxwindowsize)
    if n<X.shape[0]:
        X_new = np.zeros(X.shape)
        for i in range(X.shape[1]):
            X_new[:,i] = np_move_avg(X[:,i], n, mode='same')
    else:
        X_new = X
        
    return X_new

# r13 = RandoomSmoothing(X, minwindowsize=2, maxwindowsize=10, mode="same")


# dpi = 100
# fig = plt.figure(figsize=(6,4), dpi=dpi)
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] =False
# ts = 10
# ls = 13
# ax1 = fig.add_subplot(111)
# color1 = 'darkorange'
# color2 = 'bisque'
# p1, = ax1.plot(X[:,1], color=color2, alpha=alpha, label='Original Pressure')
# p2, = ax1.plot(r13[:,1], color=color1, label='RandoomSmoothing Pressure')
# ax1.set_ylabel('Pressue (cmH$_\mathrm{2}$O)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax1.tick_params(axis='y', labelcolor=color1, labelsize=ts)
# ax1.set_title("RandoomSmoothing",fontdict={'weight': 'normal', 'size': ls})

# ax2 = ax1.twinx() 
# color1 = 'lightseagreen'
# color2 = 'paleturquoise'
# p3, = ax2.plot(X[:,0], color=color2, alpha=alpha, label='Original Flow')
# p4, = ax2.plot(r13[:,0], color=color1, label='RandoomSmoothing Flow')
# ax2.set_ylabel('Flow (L/min)', color=color1, fontdict={'weight': 'normal', 'size': ls})
# ax2.tick_params(axis='y', labelcolor=color1, labelsize=ts)

# ax1.legend(handles=[p1, p2, p3, p4], loc="upper right", fontsize=ts)
# plt.savefig('./augmentation results/13-RandoomSmoothing.png', dpi=dpi)
# plt.show()
 
#%%
def add_noise(s):
    fwaveData = s[:, 0]
    pwaveData = s[:, 1]
    
    snr = random.randint(10, 40)
    snr = 10**(snr/10.0)
    
    f_xpower = np.sum(fwaveData**2)/len(fwaveData)
    f_npower = f_xpower / snr
    f_n = np.random.randn(len(fwaveData)) * np.sqrt(f_npower) # GWN
    
    p_xpower = np.sum(pwaveData**2)/len(pwaveData)
    p_npower = p_xpower / snr
    p_n = np.random.randn(len(pwaveData)) * np.sqrt(p_npower)
    
    n = np.array([f_n, p_n]).T
    
    r = s + n
    return r