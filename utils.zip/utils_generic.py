import os
import glob
import tensorflow as tf
import random
import numpy as np
from scipy import interpolate
from sklearn import preprocessing
from scipy.io import loadmat
import matplotlib.pyplot as plt
from utils.utils_augmentations import (Jittering, Scaling, MagnitudeWarping, TimeWarping, 
                           Permutation2, RandSampling, FlipX, FlipY, 
                           Masked, Crop_and_Resize, RandoomSmoothing, add_noise)
# %%

def random_apply(func, x, p):
    if tf.random.uniform([], minval=0, maxval=1) < p:
        return func(x)
    else:
        return x


def custom_augment(r, method='Combinations'):
    if method=='None':
        r = r
    if method=='Jittering':
        r = random_apply(Jittering, r, p=0.8)
    if method=='Scaling':
        r = random_apply(Scaling, r, p=0.8)
    if method=='MagnitudeWarping':
        r = random_apply(MagnitudeWarping, r, p=0.8)
    if method=='TimeWarping':
        r = random_apply(TimeWarping, r, p=0.8)
    if method=='Permutation2':
        r = random_apply(Permutation2, r, p=0.8)
    if method=='RandSampling':
        r = random_apply(RandSampling, r, p=0.8)
    if method=='FlipX':
        r = random_apply(FlipX, r, p=0.8)
    if method=='FlipY':
        r = random_apply(FlipY, r, p=0.8)
    if method=='Masked':
        r = random_apply(Masked, r, p=0.8)
    if method=='Crop_and_Resize':
        r = random_apply(Crop_and_Resize, r, p=0.8)
    if method=='RandoomSmoothing':
        r = random_apply(RandoomSmoothing, r, p=0.8)
        
    if method=='Combinations':
        r = random_apply(Jittering, r, p=0.8)
        r = random_apply(Scaling, r, p=0.8)
        r = random_apply(MagnitudeWarping, r, p=0.8)
        r = random_apply(TimeWarping, r, p=0.8)
        #r = random_apply(Permutation2, r, p=0.8)
        r = random_apply(RandSampling, r, p=0.8)
        # r = random_apply(FlipX, r, p=0.8)
        # r = random_apply(FlipY, r, p=0.8)
        r = random_apply(Masked, r, p=0.8)
        r = random_apply(Crop_and_Resize, r, p=0.8)
        r = random_apply(RandoomSmoothing, r, p=0.8)
        
    return r


def composition_of_two_transformations(r, methods=['Jittering', 'Scaling']):
    for method in methods:
        if method=='Jittering':
            r = random_apply(Jittering, r, p=0.8)
        if method=='Scaling':
            r = random_apply(Scaling, r, p=0.8)
        if method=='MagnitudeWarping':
            r = random_apply(MagnitudeWarping, r, p=0.8)
        if method=='TimeWarping':
            r = random_apply(TimeWarping, r, p=0.8)
        if method=='Permutation2':
            r = random_apply(Permutation2, r, p=0.8)
        if method=='RandSampling':
            r = random_apply(RandSampling, r, p=0.8)
        if method=='FlipX':
            r = random_apply(FlipX, r, p=0.8)
        if method=='FlipY':
            r = random_apply(FlipY, r, p=0.8)
        if method=='Masked':
            r = random_apply(Masked, r, p=0.8)
        if method=='Crop_and_Resize':
            r = random_apply(Crop_and_Resize, r, p=0.8)
        if method=='RandoomSmoothing':
            r = random_apply(RandoomSmoothing, r, p=0.8)
    return r


def custom_augment1(s):
    r = random_apply(FlipY, s, p=0.5)
    return r


def custom_augment2(s):
    r = random_apply(add_noise, s, p=0.8)
    return r

def min_max_normalization(waveData, quant=-1):
    if quant==0:
        #[0, 1]
        pwaveData = (waveData[:, 0] - min(waveData[:, 0])) / (max(waveData[:, 0]) - min(waveData[:, 0]))
        fwaveData = (waveData[:, 1] - min(waveData[:, 1])) / (max(waveData[:, 1]) - min(waveData[:, 1]))
        y = np.array([pwaveData, fwaveData]).T
    if quant==-1: 
        #[-1, 1]
        pwaveData = 2*(waveData[:, 0] - min(waveData[:, 0])) / (max(waveData[:, 0]) - min(waveData[:, 0])) - 1
        fwaveData = 2*(waveData[:, 1] - min(waveData[:, 1])) / (max(waveData[:, 1]) - min(waveData[:, 1])) - 1
        y = np.array([pwaveData, fwaveData]).T
    return y


def pre_process(data, kind='linear', length=300, norm='z-score'):
    
    scale = np.linspace(1, np.shape(data)[0], np.shape(data)[0])#resample

    new_scale = np.linspace(1, np.shape(data)[0], length)

    func_P = interpolate.interp1d(scale, data[:,0], kind=kind)
    P_new = func_P(new_scale)

    func_F = interpolate.interp1d(scale, data[:,1], kind=kind)
    F_new = func_F(new_scale)

    func_V = interpolate.interp1d(scale, data[:,2], kind=kind)
    V_new = func_V(new_scale)

    waveData = np.array([P_new, F_new, V_new]).T

    if norm=='z-score':#z-score
        r = [preprocessing.scale(waveData)][0]
    if norm=='min-max':#[-1,1]
        r = min_max_normalization(waveData, quant=-1)
    return r


def walkFile(path, type):
    filePaths = []
    dirPaths = []
    for root, dirs, files in os.walk(path):
        """
        Args:
        root represents the path of the current folder
        dirs represents the list of directories in the current folder
        files represents the list of files in the current folder
        """
        # walk all files
        for file in files:
            if type!='':
                if file.endswith(type):
                    filePaths.append(os.path.join(root, file))
            else:
                filePaths.append(os.path.join(root, file))

        # walk all dirs
        for d in dirs:
            dirPaths.append(os.path.join(root, d))
    return filePaths, dirPaths


def walkFile_current_path(path, type):
    files = glob.glob(path + '/*' + type)
    return files

