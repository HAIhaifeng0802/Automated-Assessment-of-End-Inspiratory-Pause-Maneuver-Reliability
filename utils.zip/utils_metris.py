import os, json
import shutil
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix,classification_report,f1_score,roc_auc_score
#%%
def get_metris(y_true, y_predict, y_score, classes=2):
    
    result = {}
    if classes==2:
        #task = confusion_matrix(y_test[0], pred_label[0]) #'tn=(0,0),fn=(1,0),tp=(1,1),fp=(0,1)'
        TN, FP, FN, TP = confusion_matrix(y_true, y_predict, labels=[0,1]).ravel()
        auc = roc_auc_score(y_true, y_score)
        
    if classes==3:
        confusion = confusion_matrix(y_true, y_predict)
        
        TN = confusion[0, 0]
        FP = confusion[0, 1] + confusion[0, 2]
        FN = confusion[1, 0] + confusion[2, 0]
        TP = confusion[1, 1] + confusion[2, 2]
        auc = roc_auc_score(y_true, y_score, multi_class='ovr')
        # confusion = confusion_matrix(y_test, pred_label, labels=[0, 1, 2])

    Accuray = (TP+TN)/(TP+TN+FP+FN)
    
    Sensitivity = TP/(TP+FN)
    
    Specificity = TN/(FP+TN)
    
    PositivePredictiveValue = TP/(TP+FP)
    
    NegativePredictiveValue = TN/(TN+FN)
    
    #F1_Score = 2*(Sensitivity*PositivePredictiveValue)/(Sensitivity+PositivePredictiveValue)
    F1_Score = 2*TP / (2*TP+FP+FN)
    
    # auc = roc_auc_score(y_true, y_score)
    
    result = {'acc':Accuray, 
              'sen':Sensitivity,
              'spe':Specificity,
              'ppv':PositivePredictiveValue,
              'npv':NegativePredictiveValue,
              'f1':F1_Score,
              'auc':auc}
    return  result


def plot_confusion_matrix(cm, savedir, savename, colnames):
    plt.rcParams['font.sans-serif']=['SimHei']
    plt.rcParams['axes.unicode_minus'] = False

    
    sns.set()
    fig = plt.figure(figsize=(14, 12), 
                     dpi=100,
                     tight_layout=True
                     )
    
    #names = ['Delayed Cycling', 'Premature Cycling', 'DoubleTrig', 'InefTrig', 'Other']
    
    sns.heatmap(cm, 
                annot=True, #
                annot_kws={"size": 14}, 
                cmap='hot_r', 
                fmt='.20g', 
                square=True, 
                xticklabels=colnames, 
                yticklabels=colnames,
                )
    
    plt.yticks(rotation=0)
    plt.tick_params(labelsize = 14)
    fig.axes[0].set_title('Confusion matrix', fontsize = 20) #标题                                                       
    fig.axes[0].set_xlabel('Predict', fontsize = 20) #x轴
    fig.axes[0].set_ylabel('True', fontsize = 20) #y轴
    
    #plt.savefig(os.path.join(savedir, 'confusion_matrix.png'), dpi = 100)
    plt.savefig(os.path.join(savedir, f'confusion_matrix_{savename}.png'), dpi = 100)
    #plt.show()
    plt.close(fig)



def create_folder(savedir, count):
    #save_dir = 'E:/SRRSH/z_CL/saved_models/0-None'
    labels = ['JTLX_Standard']
    #labels = ['DelayedCycling', 'PrematureCycling', 'DoubleTrig', 'InefTrig']
    filepath = os.path.join(savedir, 'predict')
    if not os.path.isdir(os.path.join(savedir, 'predict', str(count))):
        for label in labels:
            os.makedirs(os.path.join(filepath, str(count), label, 'TN'))
            os.makedirs(os.path.join(filepath, str(count), label, 'FN'))
            os.makedirs(os.path.join(filepath, str(count), label, 'TP'))
            os.makedirs(os.path.join(filepath, str(count), label, 'FP'))
 
            
def save_json(savedir, result):
    with open(os.path.join(savedir, "result.json"), "w", encoding='utf-8') as f: 
        f.write(json.dumps(result, indent=2))  

def load_json(filepath):
    with open(filepath,"r", encoding='utf-8'  ) as f:
        train_result = json.load(f)
    return train_result

def save_table(savedir, n_splits, train_result):
    colname=['JTLX_Standard', 'Other']
    #colname=['DelayedCycling', 'PrematureCycling', 'DoubleTrig', 'InefTrig', 'Other']
    accs,sens,spes,ppvs,npvs,f1s,aucs = [],[],[],[],[],[],[]
    col1,col2,col3,col4,col5,col6,col7 = [],[],[],[],[],[],[]
    fold, pva_type=[], []
    train_result_new = {}
    for col in colname[:-1]:
        acc,sen,spe,ppv,npv,f1,auc = [],[],[],[],[],[],[]
        for count in range(n_splits):
            accs.append(train_result[count][col]['acc'])
            sens.append(train_result[count][col]['sen'])
            spes.append(train_result[count][col]['spe'])
            ppvs.append(train_result[count][col]['ppv'])
            npvs.append(train_result[count][col]['npv'])
            f1s.append(train_result[count][col]['f1'])
            aucs.append(train_result[count][col]['auc'])
            
            fold.append(count)
            pva_type.append(col)
            
            acc.append(train_result[count][col]['acc'])
            sen.append(train_result[count][col]['sen'])
            spe.append(train_result[count][col]['spe'])
            ppv.append(train_result[count][col]['ppv'])
            npv.append(train_result[count][col]['npv'])
            f1.append(train_result[count][col]['f1'])
            auc.append(train_result[count][col]['auc'])
            
        fold.extend([" "])
        pva_type.extend(["avg"+'±'+"std"])
        accs.extend([str(round(np.mean(acc),3))+'±'+str(round(np.std(acc),3))])
        sens.extend([str(round(np.mean(sen),3))+'±'+str(round(np.std(sen),3))])
        spes.extend([str(round(np.mean(spe),3))+'±'+str(round(np.std(spe),3))])
        ppvs.extend([str(round(np.mean(ppv),3))+'±'+str(round(np.std(ppv),3))])
        npvs.extend([str(round(np.mean(npv),3))+'±'+str(round(np.std(npv),3))])
        f1s.extend([str(round(np.mean(f1),3))+'±'+str(round(np.std(f1),3))])
        aucs.extend([str(round(np.mean(auc),3))+'±'+str(round(np.std(auc),3))])
        
        col1 = col1 + acc
        col2 = col2 + sen
        col3 = col3 + spe
        col4 = col4 + ppv
        col5 = col5 + npv
        col6 = col6 + f1
        col7 = col7 + auc
        
        tmp = {"acc":acc, "sen":sen, "spe":spe, "ppv":ppv, "npv":npv, "f1":f1, "auc":auc}
        train_result_new.update({col : tmp})
    
    fold.extend([" "])
    pva_type.extend(["avg_all"+'±'+"std_all"])
    accs.extend([str(round(np.mean(col1),3))+'±'+str(round(np.std(col1),3))])
    sens.extend([str(round(np.mean(col2),3))+'±'+str(round(np.std(col2),3))])
    spes.extend([str(round(np.mean(col3),3))+'±'+str(round(np.std(col3),3))])
    ppvs.extend([str(round(np.mean(col4),3))+'±'+str(round(np.std(col4),3))])
    npvs.extend([str(round(np.mean(col5),3))+'±'+str(round(np.std(col5),3))])
    f1s.extend([str(round(np.mean(col6),3))+'±'+str(round(np.std(col6),3))])
    aucs.extend([str(round(np.mean(col7),3))+'±'+str(round(np.std(col7),3))])
    
    df = pd.DataFrame({"fold":fold, 
                       "pva_type":pva_type, 
                       "acc":accs,
                       "sen":sens,
                       "spe":spes,
                       "ppv":ppvs,
                       "npv":npvs,
                       "f1":f1s,
                       "auc":aucs})
    df.to_excel(os.path.join(savedir, "result.xlsx"), index = False)
    return df

def save_table2(savedir, n_splits, train_result):
    fold = []
    colname = ['JTLX_Standard', 'Other']
    #colname = ['DelayedCycling', 'PrematureCycling', 'DoubleTrig', 'InefTrig', 'Other']
    metris = ['acc','sen','spe','ppv','npv','f1','auc']
    result = pd.DataFrame()
    for count in range(n_splits):
        fold.append(count)
        temp = train_result[count]
        temp_df = pd.DataFrame(temp).T
        temp_df.columns = metris
        
        mean_std = {}
        for m in metris:    
            mean_std.update({m:str(round(np.mean(temp_df[m]),3))+'±'+str(round(np.std(temp_df[m], ddof=0),3))})
        mean_std_df = pd.DataFrame(mean_std, index=['mean±std'])
        result_tmp = pd.concat([temp_df, mean_std_df], axis=0)
        result = pd.concat([result, result_tmp], axis=0)
        for i in range(len(colname)-1):
            fold.extend(" ")
    result = result.reset_index()
    fold_df = pd.DataFrame({'fold':fold})
    results = pd.concat([fold_df, result], axis=1)
    results.to_excel(os.path.join(savedir, "result2.xlsx"), index = False)
    return results
#%%

