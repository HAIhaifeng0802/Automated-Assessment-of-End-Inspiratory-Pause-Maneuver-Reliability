import tensorflow as tf
from tensorflow.keras.models import Model 
from tensorflow.keras import regularizers
from tensorflow.keras.layers import Activation, Input, Lambda, Dense, Conv1D, MaxPooling1D, GlobalAveragePooling1D
from tensorflow.keras.layers import LSTM, BatchNormalization, Dropout, Bidirectional, Reshape, Flatten
from tensorflow.keras.layers import Add, Concatenate, Average
from tensorflow.keras.utils import plot_model


def slice(x,index):  
    return x[:,:,index] 
 


def SmallCNN(maxlen=300, drop_rate=0.1, width_multiple=1, classes=3, classifier_activation=None, 
             model_name='small_cnn1d', 
             classify=False,
             active_learner=False,
             include_top=False,
             #label_count = [['DelayedCycling', 2], ['PrematureCycling', 2], ['DoubleTrig', 2], ['InefTrig', 2]],
             label_count = [['DelayedCycling', 2], ['PrematureCycling', 2], ['DoubleTrig', 2], ['InefTrig', 2], ['JTLX', 3]],
             **kwargs):
    
    inputs = Input(shape=(maxlen, 3)) 

    x1 = Lambda(slice, output_shape=(maxlen, 1), arguments={'index':0})(inputs)
    x1 = Reshape((maxlen, 1))(x1)
    x1 = Conv1D(filters=256*width_multiple, kernel_size=11, strides=1, padding='same', use_bias=True, name='conv1d_11')(x1)
    x1 = BatchNormalization(epsilon=1.001e-5, name='bn_11')(x1)
    x1 = Activation('relu')(x1) 
    x1 = MaxPooling1D(pool_size=2, strides=2, padding='same')(x1)
    x1 = Dropout(drop_rate)(x1)

    x1 = Conv1D(filters=128*width_multiple, kernel_size=5, strides=1, padding='same', use_bias=True, name='conv1d_12', dilation_rate = 2)(x1)
    x1 = BatchNormalization(epsilon=1.001e-5, name='bn_12')(x1)
    x1 = Activation('relu')(x1) 
    x1 = Dropout(drop_rate)(x1)

    x1 = Conv1D(filters=64*width_multiple, kernel_size=5, strides=1, padding='same', use_bias=True, name='conv1d_13', dilation_rate = 2)(x1)
    x1 = BatchNormalization(epsilon=1.001e-5, name='bn_13')(x1)
    x1 = Activation('relu')(x1) 
    x1 = Dropout(drop_rate)(x1)

    x1 = Conv1D(filters=64*width_multiple, kernel_size=3, strides=1, padding='same', use_bias=True, name='conv1d_14', dilation_rate = 4)(x1)
    x1 = BatchNormalization(epsilon=1.001e-5, name='bn_14')(x1)
    x1 = Activation('relu')(x1) 
    x1 = Dropout(drop_rate)(x1)

    x1 = Conv1D(filters=32*width_multiple, kernel_size=3, strides=1, padding='same', use_bias=True, name='conv1d_15', dilation_rate = 4)(x1)
    x1 = BatchNormalization(epsilon=1.001e-5, name='bn_15')(x1)
    x1 = Activation('relu')(x1)
    x1 = MaxPooling1D(pool_size=2, strides=2, padding='same')(x1)
    x1 = Dropout(drop_rate)(x1)
    
    x2 = Lambda(slice, output_shape=(maxlen, 1), arguments={'index':1})(inputs)
    x2 = Reshape((maxlen, 1))(x2)  
    x2 = Conv1D(filters=256*width_multiple, kernel_size=11, strides=1, padding='same', use_bias=True, name='conv1d_21')(x2)
    x2 = BatchNormalization(epsilon=1.001e-5, name='bn_21')(x2)
    x2 = Activation('relu')(x2) 
    x2 = MaxPooling1D(pool_size=2, strides=2, padding='same')(x2)
    x2 = Dropout(drop_rate)(x2)

    x2 = Conv1D(filters=128*width_multiple, kernel_size=5, strides=1, padding='same', use_bias=True, name='conv1d_22', dilation_rate = 2)(x2)
    x2 = BatchNormalization(epsilon=1.001e-5, name='bn_22')(x2)
    x2 = Activation('relu')(x2) 
    x2 = Dropout(drop_rate)(x2)

    x2 = Conv1D(filters=64*width_multiple, kernel_size=5, strides=1, padding='same', use_bias=True, name='conv1d_23', dilation_rate = 2)(x2)
    x2 = BatchNormalization(epsilon=1.001e-5, name='bn_23')(x2)
    x2 = Activation('relu')(x2) 
    x2 = Dropout(drop_rate)(x2)

    x2 = Conv1D(filters=64*width_multiple, kernel_size=3, strides=1, padding='same', use_bias=True, name='conv1d_24', dilation_rate = 4)(x2)
    x2 = BatchNormalization(epsilon=1.001e-5, name='bn_24')(x2)
    x2 = Activation('relu')(x2) 
    x2 = Dropout(drop_rate)(x2)

    x2 = Conv1D(filters=32*width_multiple, kernel_size=3, strides=1, padding='same', use_bias=True, name='conv1d_25', dilation_rate = 4)(x2)
    x2 = BatchNormalization(epsilon=1.001e-5, name='bn_25')(x2)
    x2 = Activation('relu')(x2)
    x2 = MaxPooling1D(pool_size=2, strides=2, padding='same')(x2)
    x2 = Dropout(drop_rate)(x2)


    x3 = Lambda(slice, output_shape=(maxlen, 1), arguments={'index':2})(inputs)
    x3 = Reshape((maxlen, 1))(x3)
    x3 = Conv1D(filters=256*width_multiple, kernel_size=11, strides=1, padding='same', use_bias=True, name='conv1d_31')(x3)
    x3 = BatchNormalization(epsilon=1.001e-5, name='bn_31')(x3)
    x3 = Activation('relu')(x3) 
    x3 = MaxPooling1D(pool_size=2, strides=2, padding='same')(x3)
    x3 = Dropout(drop_rate)(x3)

    x3 = Conv1D(filters=128*width_multiple, kernel_size=5, strides=1, padding='same', use_bias=True, name='conv1d_32', dilation_rate = 2)(x3)
    x3 = BatchNormalization(epsilon=1.001e-5, name='bn_32')(x3)
    x3 = Activation('relu')(x3) 
    x3 = Dropout(drop_rate)(x3)

    x3 = Conv1D(filters=64*width_multiple, kernel_size=5, strides=1, padding='same', use_bias=True, name='conv1d_33', dilation_rate = 2)(x3)
    x3 = BatchNormalization(epsilon=1.001e-5, name='bn_33')(x3)
    x3 = Activation('relu')(x3) 
    x3 = Dropout(drop_rate)(x3)

    x3 = Conv1D(filters=64*width_multiple, kernel_size=3, strides=1, padding='same', use_bias=True, name='conv1d_34', dilation_rate = 4)(x3)
    x3 = BatchNormalization(epsilon=1.001e-5, name='bn_34')(x3)
    x3 = Activation('relu')(x3) 
    x3 = Dropout(drop_rate)(x3)

    x3 = Conv1D(filters=32*width_multiple, kernel_size=3, strides=1, padding='same', use_bias=True, name='conv1d_35', dilation_rate = 4)(x3)
    x3 = BatchNormalization(epsilon=1.001e-5, name='bn_35')(x3)
    x3 = Activation('relu')(x3)
    x3 = MaxPooling1D(pool_size=2, strides=2, padding='same')(x3)
    x3 = Dropout(drop_rate)(x3)
    
    x = Add(name='add')([x1, x2, x3])
       
    if active_learner:
        x = Flatten(name='flatten')(x)
        x = Dense(128, activation='relu', name='embedding')(x)
        x = [Dense(count, activation='softmax', name=name)(x) for name, count in label_count]
    elif include_top:
        x = GlobalAveragePooling1D(name='avg_pool')(x)
        # x = Flatten(name='flatten')(x)
        # x = Dense(128, activation='relu', name='embedding')(x)
        x = Dense(classes, activation='softmax', name='predictions')(x)
    else:
        x = GlobalAveragePooling1D(name='avg_pool')(x)

    if classify:
        x = [Dense(count, activation='softmax', name=name)(x) for name, count in label_count]
        
        
    f = Model(inputs, x, name=model_name)
    
    return f


