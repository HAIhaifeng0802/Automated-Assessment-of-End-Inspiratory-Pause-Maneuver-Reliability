import os
import matplotlib.pyplot as plt
from tensorflow import keras
from tensorflow.keras.callbacks import Callback
import numpy as np
import json


def plot_progress(history, savepath, save_history='history.npy'):
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    p1, = ax1.plot(history.history["accuracy"], 'r', label="train_acc")
    p2, = ax1.plot(history.history["val_accuracy"], 'b', label="val_acc") 
    ax1.set_ylabel('accuracy')
    ax1.set_xlabel('epoch')
    ax1.set_title("Training Progress")
    ax1.grid()
    
    ax2 = ax1.twinx() 
    p3, = ax2.plot(history.history["loss"], 'g', label="train_loss")
    p4, = ax2.plot(history.history["val_loss"], 'k', label="val_loss")
    ax2.set_ylabel('loss')
    
    ax1.legend(handles=[p1, p2, p3, p4], loc="upper right")
    #plt.show()
    plt.savefig(savepath)
    
    if save_history!='':
        np.save(save_history, history.history)
        

def plot_contrast_training_curves(pretraining_history, savepath, save_history='history.npy'):
    # with val acc
    '''
    fig = plt.figure()
    ax1 = fig.add_subplot(111)

    p1, = ax1.plot(pretraining_history.history["c_acc"], 'r', label="c_acc")
    p2, = ax1.plot(pretraining_history.history["p_acc"], 'b', label="train_p_acc") 
    p3, = ax1.plot(pretraining_history.history["val_p_acc"], 'g', label="val_p_acc") 
    ax1.set_ylabel('accuracy')
    ax1.set_xlabel('epoch')
    ax1.set_title("Training Progress")
    ax1.grid()
    
    ax2 = ax1.twinx() 
    p4, = ax2.plot(pretraining_history.history["c_loss"], 'k', label="c_loss")
    p5, = ax2.plot(pretraining_history.history["p_loss"], 'orange', label="train_p_loss")
    p6, = ax2.plot(pretraining_history.history["val_p_loss"], 'cyan', label="val_p_loss")
    ax2.set_ylabel('loss')
    
    ax1.legend(handles=[p1, p2, p3, p4, p5, p6], loc="upper right")
    
    #plt.show()
    plt.savefig(savepath)
    plt.close(fig)
    if save_history!='':
        np.save(save_history, pretraining_history.history)
    '''
    
    fig = plt.figure()
    ax1 = fig.add_subplot(111)

    p1, = ax1.plot(pretraining_history.history["c_acc"], 'r', label="c_acc")
    ax1.set_ylabel('accuracy')
    ax1.set_xlabel('epoch')
    ax1.set_title("Training Progress")
    ax1.grid()
    
    ax2 = ax1.twinx() 
    p4, = ax2.plot(pretraining_history.history["c_loss"], 'k', label="c_loss")
    ax2.set_ylabel('loss')
    
    ax1.legend(handles=[p1, p4], loc="upper right")
    
    #plt.show()
    plt.savefig(savepath)
    plt.close(fig)
    if save_history!='':
        np.save(save_history, pretraining_history.history)
        
    
    
    
def plot_progress_multi_task(history, save_dir, save_history='history.npy',
                            #  label_count = [['DelayedCycling', 2], ['PrematureCycling', 2], ['DoubleTrig', 2], ['InefTrig', 2], ['JTLX', 3]]
                             #label_count = [['DelayedCycling', 2], ['PrematureCycling', 2], ['DoubleTrig', 2], ['InefTrig', 2]]
                             ):
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    p1, = ax1.plot(np.array(history.history['accuracy']), 'r', label="train_acc")
    
    p2, = ax1.plot(np.array(history.history[f'accuracy']), 'b', label="val_acc") 
    
    # p1, = ax1.plot((np.array(history.history[f'{label_count[0][0]}_accuracy'])+
    #           np.array(history.history[f'{label_count[1][0]}_accuracy'])+
    #           np.array(history.history[f'{label_count[2][0]}_accuracy'])+
    #           np.array(history.history[f'{label_count[3][0]}_accuracy']))/4, 'r', label="train_acc")
    
    # p2, = ax1.plot((np.array(history.history[f'val_{label_count[0][0]}_accuracy'])+
    #           np.array(history.history[f'val_{label_count[1][0]}_accuracy'])+
    #           np.array(history.history[f'val_{label_count[2][0]}_accuracy'])+
    #           np.array(history.history[f'val_{label_count[3][0]}_accuracy']))/4, 'b', label="val_acc")
    ax1.set_ylabel('accuracy')
    ax1.set_xlabel('epoch')
    ax1.set_title("Training Progress")
    ax1.grid()

    ax2 = ax1.twinx() 
    p3, = ax2.plot(history.history["loss"], 'g', label="train_loss")
    p4, = ax2.plot(history.history["val_loss"], 'k', label="val_loss")
    ax2.set_ylabel('loss')

    ax1.legend(handles=[p1, p2, p3, p4], loc="upper right")
    plt.savefig(os.path.join(save_dir, 'acc-loss.png'))
    #plt.show()
    plt.close(fig)
    if save_history!='':
        np.save(save_history, history.history)


def load_history(path):
    history = np.load(path, allow_pickle=True)[()]
    return history






