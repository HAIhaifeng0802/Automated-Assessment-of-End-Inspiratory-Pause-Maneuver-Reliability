import tensorflow as tf
from tensorflow.keras.models import Model 
from tensorflow.keras import regularizers
from tensorflow.keras.layers import Activation, Input, Lambda, Dense, Conv1D, MaxPooling1D, GlobalAveragePooling1D
from tensorflow.keras.layers import LSTM, BatchNormalization, Dropout, Bidirectional, Reshape, Flatten
from tensorflow.keras.layers import Add, Concatenate, Average


# Non-linear MLP as projection head
def get_projection(project_dim=128):
    inputs = Input(shape=(project_dim,))
    # inputs = Input(shape=input_shape)
    
    x = Dense(project_dim, activation="relu", name='projection_1')(inputs)
    p = Dense(project_dim, name='projection_2')(x)
    
    h = Model(inputs, p, name="projection_head")
    return h


def get_linear_classifier(feature_backbone, maxlen=300, n_classes=2, trainable=False, name="linear_model"):
    inputs = Input(shape=(maxlen, 2))
    
    feature_backbone.trainable = trainable
    x = feature_backbone(inputs, training=trainable)
    outputs = Dense(n_classes, activation="softmax", )(x)
    linear_model = Model(inputs, outputs, name=name)

    return linear_model


def get_linear_multi_task_classifier(feature_backbone, 
                                     maxlen=300, 
                                     trainable=False, 
                                     label_count = [['CycleProlong', 2], ['CycleProshort', 2], ['DoubleTrig', 2], ['InefTrig', 2]],
                                     name='multi_classification_model',
                                     ):
    '''
    inputs = Input(shape=(maxlen, 2))
    
    feature_backbone.trainable = trainable
    x = feature_backbone(inputs, training=trainable)
    outputs = [Dense(count, activation='softmax', name=name)(x) for name, count in label_count]
    linear_model = Model(inputs, outputs, name=name)
    '''
    feature_backbone.trainable = trainable
    linear_model = tf.keras.Sequential(
        [Input(shape=(maxlen, 2)),
         feature_backbone,
         [Dense(2, activation='softmax', name='CycleProlong'), 
          Dense(2, activation='softmax', name='CycleProshort'),
          Dense(2, activation='softmax', name='DoubleTrig'),
          Dense(2, activation='softmax', name='InefTrig')],
         ],
        name=name,
        )

    return linear_model


def get_active_learner(backbone,
                       maxlen=300, 
                       trainable=False,
                       label_count = [['CycleProlong', 2], ['CycleProshort', 2], ['DoubleTrig', 2], ['InefTrig', 2]],
                       name='active_learner',
                       ):
    
    
    inputs = Input(shape=(maxlen, 2))
    
    backbone.trainable = trainable
    x1, x2 = backbone(inputs, training=trainable)
    
    x = Add(name='add')([x1, x2])
    x = Flatten(name='flatten')(x)
    x = Dense(128, activation='relu', name='embedding')(x)
    
    outputs = [Dense(count, activation='softmax', name=name)(x) for name, count in label_count]
    
    active_learner = Model(inputs, outputs, name=name)
    
    return active_learner

# Contrastive learning Model
class ContrastiveModel(tf.keras.Model):
    def __init__(self, temperature, encoder, projection_head):
        super().__init__()

        self.temperature = temperature
        self.encoder = encoder
        self.projection_head = projection_head
        
        self.encoder.summary()
        self.projection_head.summary()


    def compile(self, contrastive_optimizer, **kwargs):
        super().compile(**kwargs)

        self.contrastive_optimizer = contrastive_optimizer

        # self.contrastive_loss will be defined as a method
        self.contrastive_loss_tracker = tf.keras.metrics.Mean(name="c_loss")
        self.contrastive_accuracy = tf.keras.metrics.SparseCategoricalAccuracy(name="c_acc")


    @property
    def metrics(self):
        return [
            self.contrastive_loss_tracker,
            self.contrastive_accuracy,
        ]

    def contrastive_loss(self, projections_1, projections_2):
        # InfoNCE loss (information noise-contrastive estimation)
        # NT-Xent loss (normalized temperature-scaled cross entropy)

        # Cosine similarity: the dot product of the l2-normalized feature vectors
        projections_1 = tf.math.l2_normalize(projections_1, axis=1)
        projections_2 = tf.math.l2_normalize(projections_2, axis=1)
        similarities = (tf.matmul(projections_1, projections_2, transpose_b=True) / self.temperature)

        # The similarity between the representations of two augmented views of the same image should be higher than their similarity with other views
        batch_size = tf.shape(projections_1)[0]
        contrastive_labels = tf.range(batch_size)
        self.contrastive_accuracy.update_state(contrastive_labels, similarities)
        self.contrastive_accuracy.update_state(contrastive_labels, tf.transpose(similarities))

        # The temperature-scaled similarities are used as logits for cross-entropy a symmetrized version of the loss is used here
        loss_1_2 = tf.keras.losses.sparse_categorical_crossentropy(contrastive_labels, similarities, from_logits=True)
        
        loss_2_1 = tf.keras.losses.sparse_categorical_crossentropy(contrastive_labels, tf.transpose(similarities), from_logits=True)
        
        return (loss_1_2 + loss_2_1) / 2

    def train_step(self, data):
        # Unpack the data.
        (ds_one, ds_two) = data
        
        with tf.GradientTape() as tape:
            features_1 = self.encoder(ds_one, training=True)
            features_2 = self.encoder(ds_two, training=True)
            # The representations are passed through a projection mlp
            projections_1 = self.projection_head(features_1, training=True)
            projections_2 = self.projection_head(features_2, training=True)
            contrastive_loss = self.contrastive_loss(projections_1, projections_2)
        gradients = tape.gradient(contrastive_loss,
                                  self.encoder.trainable_weights + self.projection_head.trainable_weights,
                                  )
        
        self.contrastive_optimizer.apply_gradients(
            zip(gradients,
                self.encoder.trainable_weights + self.projection_head.trainable_weights,
                )
            )
        
        self.contrastive_loss_tracker.update_state(contrastive_loss)

        return {m.name: m.result() for m in self.metrics}

    def test_step(self, data):
        test_data, labels = data

        # For testing the components are used with a training=False flag
        features = self.encoder(test_data, training=False)
        class_logits = self.linear_probe(features, training=False)
        probe_loss = self.probe_loss(labels, class_logits)
        self.probe_loss_tracker.update_state(probe_loss)
        self.probe_accuracy.update_state(labels, class_logits)

        # Only the probe metrics are logged at test time
        return {m.name: m.result() for m in self.metrics[2:]}
    
    def call(self, data, training=True):
        # your custom code when you call the model or just pass, you don't need this method for training
        pass